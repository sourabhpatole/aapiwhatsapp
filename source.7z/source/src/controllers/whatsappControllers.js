const fs = require("fs");
const myConsole = new console.Console(fs.createWriteStream("./logs.txt"));

const VerifyToken = (req, res) => {
  res.send("Hi Verified ");
};

const ReceiveMessages = (req, res) => {
  res.send("Hi Received");
};

module.exports = { VerifyToken, ReceiveMessages };
